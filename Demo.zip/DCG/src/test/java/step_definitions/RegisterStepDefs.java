package step_definitions;

import Pages.HomePage;
import Pages.RegisterPage;
import Pages.SignInPage;
import Utils.Config;
import Utils.Driver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.it.Ma;
import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterStepDefs {

    HomePage homePage = new HomePage();
    RegisterPage registerPage = new RegisterPage();
    SignInPage signInPage = new SignInPage();


    WebDriverWait webDriverWait = new WebDriverWait(Driver.getDriver(),10);


    @Given("Anonymous guest is on the Home page")
    public void anonymous_guest_is_on_the_Home_page() {

        homePage.navigateToHomePage();
    }

    @When("Guest clicks on the Sing in button")
    public void guest_clicks_on_the_Sing_in_button() {
        webDriverWait.until(ExpectedConditions.elementToBeClickable(homePage.getAccountSignInButton()));
        homePage.getAccountSignInButton().click();

    }

    @Then("Sing in page is getting displayed")
    public void sing_in_page_is_getting_displayed() {

        String actualTitle = Driver.getDriver().getTitle();
        Assert.assertEquals(actualTitle, Config.getProperty("SignInPageTitle"));
    }

    @Then("Guest clicks on the Create an account button")
    public void guest_clicks_on_the_Create_an_account_button() {

        webDriverWait.until(ExpectedConditions.elementToBeClickable(signInPage.getCreateAccountButton()));
        signInPage.getCreateAccountButton().click();

    }

    @Then("Register page is getting displayed")
    public void register_page_is_getting_displayed() {

        String actualTitle = Driver.getDriver().getTitle();
        Assert.assertEquals(actualTitle,Config.getProperty("RegisterTitle"));

    }

    @Given("Guest types first name {string}")
    public void guest_types_first_name(String firstName) {

        Pattern pattern = Pattern.compile("[A-Z][a-z]*");
        Matcher matcher = pattern.matcher(firstName);

        if(matcher.matches()){
            webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getFirstNameField()));
            registerPage.getFirstNameField().sendKeys(firstName);
        }else{

            throw new RuntimeException();
        }

    }

    @Then("Guest types last name {string}")
    public void guest_types_last_name(String lastName) {

        Pattern pattern = Pattern.compile("[A-Z][a-z]*");
        Matcher matcher = pattern.matcher(lastName);

        if(matcher.matches()){
            webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getLastNameField()));
            registerPage.getFirstNameField().sendKeys(lastName);
        }else{

            throw new RuntimeException();
        }

    }

    @Then("Guest types street address {string}")
    public void guest_types_street_address(String Address) {

        Pattern pattern = Pattern.compile("\\d+\\s+([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)");
        Matcher matcher = pattern.matcher(Address);
        if (matcher.matches()){
            webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getStreetAddressField()));
            registerPage.getStateField().sendKeys(Address);

        }else {
            throw new RuntimeException();
        }

    }

    @Then("Guest types apt number {string}")
    public void guest_types_apt_number(String apt) {

        String regex = "[0-9]*(?i)\\b[a-z]+\\b";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(apt);

        if(apt.isEmpty()){
            Assert.assertTrue("it is an optional field",true);
        }else{
            if(matcher.matches()){
                webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getAptField()));
                registerPage.getAptField().sendKeys(apt);
            }else {
                throw new RuntimeException();
            }
        }

    }

    @Then("Guest types Zip code {string}")
    public void guest_types_Zip_code(String zipCode) {

        String regex = "^[0-9]{5}(?:-[0-9]{4})?$";
        webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getZipCodeField()));
        registerPage.getZipCodeField().sendKeys(zipCode);

    }

    @Then("Guest types city {string}")
    public void guest_types_city(String city) {

        Pattern pattern = Pattern.compile("[A-Z][a-z]*");
        Matcher matcher = pattern.matcher(city);

        if(matcher.matches()){
            webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getCityField()));
            registerPage.getCityField().sendKeys(city);
        }else{
            throw new RuntimeException();        }

    }

    @Then("Guest selects state {string}")
    public void guest_selects_state(String state) {

        webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getStateField()));
        registerPage.getStateField().click();
        Select select = new Select(registerPage.getStateField());
        select.selectByVisibleText(state);
        Assert.assertEquals(state,Config.getProperty("state"));

    }

    @Then("Guest types phone number {string}")
    public void guest_types_phone_number(String phoneNumber) {

        if (phoneNumber.matches("\\d{10}")){
            webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getPhoneNumberField()));
            registerPage.getPhoneNumberField().sendKeys(phoneNumber);
        }else if (phoneNumber.matches("\\d{3}[-\\.\\s]\\d{4}")){
            webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getPhoneNumberField()));
            registerPage.getPhoneNumberField().sendKeys(phoneNumber);
        }else if(phoneNumber.matches("\\d{3}-\\d{3}-\\d{4}\\s(x|(ext))\\d{3,5}")){
            webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getPhoneNumberField()));
            registerPage.getPhoneNumberField().sendKeys(phoneNumber);
        }else if (phoneNumber.matches("\\(\\d{3}\\)-\\d{3}-\\d{4}")){
            webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getPhoneNumberField()));
            registerPage.getPhoneNumberField().sendKeys(phoneNumber);
        }else {
            throw new RuntimeException();
        }

        }

    @Then("Guest types email address {string}")
    public void guest_types_email_address(String email) {


        Pattern pattern = Pattern.compile("\\w{10}\\@gmail\\.com}");
        Matcher matcher = pattern.matcher(email);

        if(matcher.matches()){
            webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getEmailField()));
            registerPage.getEmailField().sendKeys(email);
        }else{
            throw new RuntimeException();        }

    }

    @Then("Guest types password {string}")
    public void guest_types_password(String password) {

        String passwordPattern = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z]).{7,18})";
        if (password.length()<8||password.length()>18){
            Assert.assertFalse("incorrect password",false);
        }else {
            if(password.length()>=8||password.length()<=18) {

                Pattern pattern = Pattern.compile(passwordPattern);
                Matcher matcher = pattern.matcher(password);
                webDriverWait.until(ExpectedConditions.visibilityOf(registerPage.getCreatePasswordField()));
                registerPage.getCreatePasswordField().sendKeys(password);
            }
        }

    }

    @Then("Clicks on the CreateAccount button")
    public void clicks_on_the_CreateAccount_button() {
        webDriverWait.until(ExpectedConditions.elementToBeClickable(registerPage.getCreateAccountButton()));
        registerPage.getCreateAccountButton().click();


    }


}
