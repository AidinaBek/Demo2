package Utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.Assert;

public class APIUtils {


    private static  ResponseBody responseBody;

    public static void hitGET(String resource){

        String  uri = Config.getProperty("baseUrl")+resource;
        Response response = RestAssured.get(uri);
        System.out.println(response.asString());

        Assert.assertEquals("GET API failed",200,response.statusCode());
        ObjectMapper objectMapper = new ObjectMapper();
        try {

            ResponseBody responseBody = objectMapper.readValue(response.asString(), ResponseBody.class);
        }catch (Exception e){
            e.printStackTrace();




        }

    }

    public static ResponseBody getResponceBody (){
        return responseBody;
    }
}
