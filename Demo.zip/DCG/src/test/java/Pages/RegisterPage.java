package Pages;

import Utils.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPage {

    public RegisterPage(){
        PageFactory.initElements(Driver.getDriver(),this);

    }

    @FindBy(xpath = "//input[@name='FirstName']")
    private WebElement FirstNameField;

    @FindBy(xpath = "//input[@name='LastName']")
    private WebElement lastNameField;

    @FindBy(xpath = "//input[@name='Domestic.Address1']")
    private WebElement streetAddressField;

    @FindBy(xpath = "//input[@name='Domestic.Address2']")
    private WebElement aptField;

    @FindBy(xpath = "//input[@name='Domestic.ZipCode']")
    private WebElement zipCodeField;


    @FindBy(xpath = "//input[@name='Domestic.City']")
    private WebElement cityField;

    @FindBy(xpath = "//select[@id='Domestic_State']")
    private WebElement stateField;


    @FindBy(xpath = "//input[@id='Domestic_DaytimePhone']")
    private WebElement phoneNumberField;

    @FindBy(xpath = "//input[@id='EmailCredentials_Email']")
    private WebElement emailField;

    @FindBy(xpath = "//input[@id='accountPassword']")
    private WebElement createPasswordField;

    @FindBy(xpath = "//label[@class='revealPassword a11y-checkbox-label'] ")
    private WebElement revealPasswordCheckBox;

    @FindBy(xpath = "//label[@class='checkbox-txt col-sm-10 a11y-checkbox-label'] ")
    private WebElement notificationCheckBox;

    @FindBy(xpath = "//button[@class='button button-primary btn-block button-md aut-account-login-create-account-button']")
    private WebElement createAccountButton;

    public WebElement getFirstNameField() {
        return FirstNameField;
    }

    public WebElement getLastNameField() {
        return lastNameField;
    }

    public WebElement getStreetAddressField() {
        return streetAddressField;
    }

    public WebElement getAptField() {
        return aptField;
    }

    public WebElement getZipCodeField() {
        return zipCodeField;
    }

    public WebElement getCityField() {
        return cityField;
    }

    public WebElement getStateField() {
        return stateField;
    }

    public WebElement getPhoneNumberField() {
        return phoneNumberField;
    }

    public WebElement getCreatePasswordField() {
        return createPasswordField;
    }

    public WebElement getRevealPasswordCheckBox() {
        return revealPasswordCheckBox;
    }

    public WebElement getNotificationCheckBox() {
        return notificationCheckBox;
    }

    public WebElement getCreateAccountButton() {
        return createAccountButton;
    }

    public WebElement getEmailField() {
        return emailField;
    }
}
